
<div align="center">
<bold><strong><h1> #Sparko </h1></strong></bold>

All in one security bot with latest tech , These is a official  Repo of CodeX bot ! 




## Features 
- Anti Nuke
- Moderation
- Welcome
- Games
- Voice Role
- Fun
- Custom Roles
- Developer Commands
- No Prefix & Blacklist System
- Multi Guild
- Giveaways
- Whitelist System 
- Much More 
</div>


## Screenshots

![App Screenshot](https://media.discordapp.net/attachments/1081177626720342048/1081516718779793439/Screenshot_2023-03-04-15-30-31-11_572064f74bd5f9fa804b05334aa4f912.jpg)


## Installation

Use node v16+

```bash
  npm install
  node index.js
```

- Provide information on core/settings
- In config.js provide token or you can use env 
## ENV FORMAT FOR token
token = YOUR BOT TOKEN