const { MessageEmbed } = require("discord.js");
const Discord  = require("discord.js");

module.exports = {
    name: "stats",
    category: "info",
    aliases: ['botinfo'],
    usage: "stats",
    run: async (client, message, args, guildData, player, prefix) => {
        try {
            let dev = [], cdev = [], supp =[];
            let user = await client.users.fetch(`553336882314870801`);//Nikhil
            dev.push(`[${user.username}](https://discord.com/users/553336882314870801)`);

            user = await client.users.fetch(`870179991462236170`);//Ray
            dev.push(`[${user.username}](https://discord.com/users/870179991462236170)`);
            user = await client.users.fetch(`870179991462236170`);//Ray
            supp.push(`[${user.username}](https://discord.com/users/870179991462236170)`);
            user = await client.users.fetch(`553336882314870801`);//Nikhil 
            supp.push(`[${user.username}](https://discord.com/users/553336882314870801)`);
          
            const statsEmbed = new Discord.MessageEmbed()
			        .setColor(client.color)
              .setAuthor(`${client.user.username} 's Information`, client.user.displayAvatarURL())
              .setThumbnail(message.guild.iconURL({dynamic: true}))
              .setDescription(`**Bot's Mention: <@${client.user.id}>\nBot's Tag: ${client.user.tag}\nTotal Servers: ${client.guilds.cache.size}\nTotal Users: ${client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0)}\nTotal Channels: ${client.channels.cache.size}**`)
              .addFields([
                {name: `**__Developers__**  <a:DEVLOPER:1077523312474857522>`, value: dev.join(`, `) },
                {name: `**__Supporters__** <a:sh_supporter:1077523494847397898>`, value: supp.join(`, `) }
              ])
            message.channel.send({embeds: [statsEmbed]});
        } catch (e) {
          const emesdf = new MessageEmbed()
    			.setColor(client.color)
		    	.setAuthor(`An Error Occurred`)
			    .setDescription(`\`\`\`${e.message}\`\`\``);
			    return message.channel.send({embeds: [emesdf]});
        }
    }
}