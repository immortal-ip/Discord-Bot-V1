const { MessageEmbed } = require('discord.js'),
  st = require('../../core/settings').bot;


module.exports = {
  name: 'antinuke',
  aliases: ['antiwizz', 'an'],
  category: 'security',
  run: async (client, message, args) => {
    let prefix = message.guild.prefix || '&';
    const option = args[0];
    const isActivatedAlready = await client.db.get(`${message.guild.id}_antinuke`);
    const antinuke = new MessageEmbed()
      .setThumbnail(`${client.user.avatarURL({ dynamic: true })}`)
      .setColor(client.color)
      .setTitle(`__**Antinuke**__`)
      .setDescription(`<a:de_dot:1077422648646193264> It bans admins for doing suspicious activites in the server.\n<a:de_dot:1077422648646193264> It ignores the ones who are whitelisted.\n<a:de_dot:1077422648646193264> Antinuke must me enabled to protect the server.`)
      .addFields([
        { name: `__**Antinuke Enable**__`, value: `To Enable Antinuke, Use - \`${prefix}antinuke enable\`` },
        { name: `__**Antinuke Disable**__`, value: `To Disable Antinuke, Use - \`${prefix}antinuke disable\`` }
      ])

    if (message.author.id === message.guild.ownerId) {
      if (!option) {
        message.reply({ embeds: [antinuke] });
      } else if (option === 'enable') {
        if (isActivatedAlready) {
          const enabnble = new MessageEmbed()
            .setThumbnail(client.user.displayAvatarURL())
            .setColor(client.color)
            .setDescription(`**  ${message.guild.name} security settings <a:de_protect:1077511050045427713>
Ohh uh! looks like your server has already enabled security 

Current Status : <:de_cross:1081208621276340294><:de_tick:1081208539017662554> 

To disable use ${prefix}antinuke disable **`)
          message.channel.send({ embeds: [enabnble] })
        } else {
          await client.db.set(`${message.guild.id}_antinuke`, true);
          const enable = new MessageEmbed()
            .setThumbnail(client.user.displayAvatarURL())
            .setAuthor({name: `${client.user.username} Security`, iconURL: client.user.displayAvatarURL()})
            .setColor(client.color)
            .setDescription(`
    **  ${message.guild.name} Security Settings ** <a:de_protect:1077511050045427713>
** Also move my role to top of roles for me to work properly **<:de_authority:1077511292480405584>
      ** 
Anti Ban <:de_cross:1081208621276340294><:de_tick:1081208539017662554>
Anti Kick <:de_cross:1081208621276340294><:de_tick:1081208539017662554>
Anti Unban <:de_cross:1081208621276340294><:de_tick:1081208539017662554>
Anti Role-Create <:de_cross:1081208621276340294><:de_tick:1081208539017662554>
Anti Role-Delete <:de_cross:1081208621276340294><:de_tick:1081208539017662554>
Anti Role-Update <:de_cross:1081208621276340294><:de_tick:1081208539017662554>
Anti Channel-Create <:de_cross:1081208621276340294><:de_tick:1081208539017662554>
Anti Channel-Delete <:de_cross:1081208621276340294><:de_tick:1081208539017662554>
Anti Channel-Update <:de_cross:1081208621276340294><:de_tick:1081208539017662554>
Anti Emoji Create <:de_cross:1081208621276340294><:de_tick:1081208539017662554>
Anti Emoji Update <:de_cross:1081208621276340294><:de_tick:1081208539017662554>
Anti Emoji Delete <:de_cross:1081208621276340294><:de_tick:1081208539017662554>
Anti Webhook Create <:de_cross:1081208621276340294><:de_tick:1081208539017662554>
Anti Webhook Update <:de_cross:1081208621276340294><:de_tick:1081208539017662554>
Anti Webhook Delete <:de_cross:1081208621276340294><:de_tick:1081208539017662554>
Anti Sticker Create <:de_cross:1081208621276340294><:de_tick:1081208539017662554>
Anti Sticker Update <:de_cross:1081208621276340294><:de_tick:1081208539017662554>
Anti Sticker Delete <:de_cross:1081208621276340294><:de_tick:1081208539017662554>
Anti Everyone/Here <:de_cross:1081208621276340294><:de_tick:1081208539017662554>
Anti Server-Update <:de_cross:1081208621276340294><:de_tick:1081208539017662554>
Anti Prune <:de_cross:1081208621276340294><:de_tick:1081208539017662554>
Anti Bot Add <:de_cross:1081208621276340294><:de_tick:1081208539017662554>
Anti Vanity Steal <:de_cross:1081208621276340294><:de_tick:1081208539017662554>

Auto Recovery <:de_cross:1081208621276340294><:de_tick:1081208539017662554>
Enabled antinuke for this server
      **`)
          message.channel.send({ embeds: [enable] })
          await client.db.set(`${message.guild.id}_wl`, { whitelisted: [] });
        }
      } else if (option === 'disable') {
        if (!isActivatedAlready) {
          const dissable = new MessageEmbed().setThumbnail(client.user.displayAvatarURL())
            .setColor(client.color)
            .setDescription(` ** ${message.guild.name} ** security settings <a:de_protect:1077511050045427713>
Ohh NO! looks like your server doesn't enabled security **

** Current Status : <:de_cross:1081208621276340294><:de_tick:1081208539017662554> **

** To enable use ${prefix}antinuke enable ** `)
          message.channel.send({ embeds: [dissable] })
        } else {
          await client.db.set(`${message.guild.id}_antinuke`, null);
          const disable = new MessageEmbed().setThumbnail(client.user.displayAvatarURL())
            .setColor(client.color)
            .setDescription(`** ${message.guild.name} security settings <a:de_protect:1077511050045427713>
Successfully disabled security settings.

 Current Status : <:de_cross:1081208621276340294><:de_tick:1081208539017662554>

To enable again use ${prefix}antinuke enable **`)
          message.channel.send({ embeds: [disable] })
        }
      }
    } else {
      message.reply({ embeds: [new MessageEmbed().setColor(client.color).setDescription('<a:de_cross:1077519266645024828> | Only Server Owner Can Run This Command.')] });
    }
  }
}