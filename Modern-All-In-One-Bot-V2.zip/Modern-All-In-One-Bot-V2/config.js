const data = {
    "token": "MTQwNjE3MDcwODY4OTY4NjU5OA.Gz_i3U.rqzplPoakl3X5AtSjv2_yiRbyxFMJjVZZ2pkbg" || process.env.token,
    "mongo": "mongodb+srv://CodeXDev:CodeX007@codex-public.lo930xf.mongodb.net/?retryWrites=true&w=majority" || process.env.mongo,

}


module.exports = data;