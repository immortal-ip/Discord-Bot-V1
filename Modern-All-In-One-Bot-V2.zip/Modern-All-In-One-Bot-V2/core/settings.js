const prefix = process.env.prefix || '&'
const status = `${prefix}help`;


module.exports = {
  bot: {
    info: {
      prefix: process.env.prefix || '&',
      token: process.env.token,
      invLink: 'https://dsc.gg/codexdev',
    },
    options: {
      founders: ['553336882314870801','870179991462236170'],
      privateMode: false,
    },
    presence: {
      name: process.env.statusText || status,
      type: 'STREAMING',
      url: 'https://codexdev.tk/'
    },
    credits: {
      developerId: ['553336882314870801', '870179991462236170'],
      developer: 'TEAM CodeX',
    }
  }
}